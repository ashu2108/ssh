.. python-gitlab documentation master file, created by
   sphinx-quickstart on Mon Dec  8 15:17:39 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to python-gitlab's documentation!
=========================================

Contents:

.. toctree::
   :maxdepth: 2

   install
   cli
   api-usage
   faq
   switching-to-v4
   api-objects
   api/gitlab
   release_notes
   changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
